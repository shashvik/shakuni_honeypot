import json
import re
import logging

logger = logging.getLogger()
logger.setLevel(logging.INFO)

# Dummy PII patterns (for demonstration only - not exhaustive or secure)
SSN_PATTERN = re.compile(r'\b\d{3}-\d{2}-\d{4}\b')
CREDIT_CARD_PATTERN = re.compile(r'\b(?:\d[ -]*?){13,16}\b') # Simple check
EMAIL_PATTERN = re.compile(r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b')

def find_pii(text):
    """Finds potential PII in a given text string."""
    findings = {}
    ssns = SSN_PATTERN.findall(text)
    if ssns:
        findings['ssn'] = ssns

    cards = CREDIT_CARD_PATTERN.findall(text)
    if cards:
        # Basic masking for logs
        findings['credit_card'] = [f"****-****-****-{card[-4:]}" for card in cards]

    emails = EMAIL_PATTERN.findall(text)
    if emails:
        findings['email'] = emails

    return findings

def handler(event, context):
    """AWS Lambda handler function (dummy)."""
    logger.info(f"Received event: {json.dumps(event)}")

    # Simulate processing some data that might contain PII
    # In a real scenario, this data would come from the event or other sources
    simulated_data = [
        {
            "id": "user123",
            "notes": "Called support, issue resolved. SSN provided: 999-00-1111. Email: test@example.com"
        },
        {
            "id": "order456",
            "details": "Payment processed with card 1234-5678-9012-3456. Confirmation sent."
        },
        {
            "id": "log789",
            "message": "User login successful."
        }
    ]

    total_pii_found = 0
    for item in simulated_data:
        text_to_scan = json.dumps(item) # Scan the whole item as text
        pii_found = find_pii(text_to_scan)
        if pii_found:
            logger.warning(f"Potential PII found in item {item.get('id', 'N/A')}: {pii_found}")
            total_pii_found += sum(len(v) for v in pii_found.values())
        else:
            logger.info(f"No PII found in item {item.get('id', 'N/A')}.")

    logger.info(f"Finished processing. Found {total_pii_found} potential PII instances.")

    # Dummy response
    return {
        'statusCode': 200,
        'body': json.dumps({
            'message': 'Processed simulated data.',
            'potential_pii_instances_found': total_pii_found
        })
    }

# Example usage (if run locally)
if __name__ == '__main__':
    logging.basicConfig(level=logging.INFO)
    test_event = {'source': 'local_test'}
    test_context = None
    result = handler(test_event, test_context)
    print(result)